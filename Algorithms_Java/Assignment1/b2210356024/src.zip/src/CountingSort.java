import java.util.Arrays;

public class CountingSort {
    public static int[] sort(int[] array) {
        // Create an array to store the count of each element, initialized to 0
        int k = max(array);
        int[] count = new int[k + 1];
        Arrays.fill(count, 0);
        // Create an output array to store the sorted elements
        int[] output = new int[array.length];
        int size = array.length;
        // Count the occurrences of each element in the input array
        for(int i = 0; i < size; i++) {
            int j = array[i];
            count[j]++;
        }
        // Modify the count array to contain the actual position of the elements in the output array
        for (int i = 1; i < k + 1; i++) count[i] += count[i - 1];
        // Build the output array based on the positions determined by the count array
        for (int i = size - 1; i >= 0; i--) {
            int j = array[i];
            count[j]--;
            output[count[j]] = array[i];
        }
        return output;
    }
    private static int max(int[] numbers) {
        int max = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }
        return max;
    }
}
