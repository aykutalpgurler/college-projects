import java.util.Arrays;
import java.util.Objects;
import java.util.Random;

public class Experiment {

    public static long[] handle(int[] input, String algorithmType, String inputType) {
        int[] inputSizes = {500, 1000, 2000, 4000, 8000, 16000, 32000, 64000, 128000, 250000};
        long[] times = new long[10];

        if (algorithmType.equals("InsertionSort")) {
            System.out.println("INSERTION SORT WITH " + (Objects.equals(inputType, "Random") ? "RANDOM" : (Objects.equals(inputType, "Sorted") ? "SORTED" : "REVERSELY SORTED")));
            for (int j = 0; j < inputSizes.length; j++) {
                long duration = 0;
                for (int i = 0; i < 10; i++) {
                    int[] subArray = getSubArray(input, inputType, inputSizes[j]);
                    long start = System.currentTimeMillis();
                    InsertionSort.sort(subArray);
                    long end = System.currentTimeMillis();
                    duration += (end - start);
                    //System.out.println((i + 1) + ". Experiment = " + (end - start));
                }
                duration /= 10;
                times[j] = duration;
                System.out.println("•Average Time with " + inputSizes[j] + " input: " + duration + "ms");
            }
        } else if (algorithmType.equals("MergeSort")) {
            System.out.println("MERGE SORT WITH " + (Objects.equals(inputType, "Random") ? "RANDOM" : (Objects.equals(inputType, "Sorted") ? "SORTED" : "REVERSELY SORTED")));
            for (int j = 0; j < inputSizes.length; j++) {
                long duration = 0;
                for (int i = 0; i < 10; i++) {
                    int[] subArray = getSubArray(input, inputType, inputSizes[j]);
                    long start = System.currentTimeMillis();
                    int[] result = MergeSort.sort(subArray);
                    long end = System.currentTimeMillis();
                    duration += (end - start);
                    //System.out.println((i + 1) + ". Experiment = " + (end - start));
                }
                duration /= 10;
                times[j] = duration;
                System.out.println("•Average Time with " + inputSizes[j] + " input: " + duration + "ms");
            }
        } else if (algorithmType.equals("CountingSort")) {
            System.out.println("COUNTING SORT WITH " + (Objects.equals(inputType, "Random") ? "RANDOM" : (Objects.equals(inputType, "Sorted") ? "SORTED" : "REVERSELY SORTED")));
            for (int j = 0; j < inputSizes.length; j++) {
                long duration = 0;
                for (int i = 0; i < 10; i++) {
                    int[] subArray = getSubArray(input, inputType, inputSizes[j]);
                    long start = System.currentTimeMillis();
                    int[] result = CountingSort.sort(subArray);
                    long end = System.currentTimeMillis();
                    duration += (end - start);
                    //System.out.println((i + 1) + ". Experiment = " + (end - start));
                }
                duration /= 10;
                times[j] = duration;
                System.out.println("•Average Time with " + inputSizes[j] + " input: " + duration + "ms");
            }
        } else if (algorithmType.equals("LinearSearch")) {
            System.out.println("LINEAR SEARCH WITH " + (Objects.equals(inputType, "Random") ? "RANDOM" : (Objects.equals(inputType, "Sorted") ? "SORTED" : "REVERSELY SORTED")));
            for (int j = 0; j < inputSizes.length; j++) {
                long duration = 0;
                for (int i = 0; i < 1000; i++) {
                    int[] subArray = getSubArray(input, inputType, inputSizes[j]);
                    Random random = new Random();
                    int randomIndex = random.nextInt(inputSizes[j]);
                    int search = subArray[randomIndex];
                    long start = System.nanoTime();
                    int idx = LinearSearch.search(subArray, search);
                    long end = System.nanoTime();
                    duration += (end - start);
                }
                duration /= 1000;
                times[j] = duration;
                System.out.println("•Average Time with " + inputSizes[j] + " input: " + duration + "ns");
            }

        } else if (algorithmType.equals("BinarySearch")) {
            System.out.println("BINARY SEARCH WITH " + (Objects.equals(inputType, "Random") ? "RANDOM" : (Objects.equals(inputType, "Sorted") ? "SORTED" : "REVERSELY SORTED")));
            for (int j = 0; j < inputSizes.length; j++) {
                long duration = 0;
                for (int i = 0; i < 1000; i++) {
                    int[] subArray = getSubArray(input, inputType, inputSizes[j]);
                    Random random = new Random();
                    int randomIndex = random.nextInt(inputSizes[j]);
                    int search = subArray[randomIndex];
                    long start = System.nanoTime();
                    int idx = BinarySearch.search(subArray, search);
                    long end = System.nanoTime();
                    duration += (end - start);
                }
                duration /= 1000;
                times[j] = duration;
                System.out.println("•Average Time with " + inputSizes[j] + " input: " + duration + "ns");
            }
        } else {
            System.out.println("Wrong Input!");
        }
        System.out.println();
        return times;
    }

    private static int[] getSubArray(int[] input, String inputType, int inputSizes) {
        int[] subArray = Arrays.copyOfRange(input, 0, inputSizes);
        if (inputType.equals("Random")) {
        } else if (inputType.equals("Sorted")) {
            Arrays.sort(subArray);
        } else if (inputType.equals("ReverselySorted")){
            Arrays.sort(subArray);
            for(int k = 0; k < subArray.length / 2; k++)
            {
                int temp = subArray[k];
                subArray[k] = subArray[subArray.length - k - 1];
                subArray[subArray.length - k - 1] = temp;
            }
        } else {
            System.out.println("Wrong Input!");
        }
        return subArray;
    }
}
