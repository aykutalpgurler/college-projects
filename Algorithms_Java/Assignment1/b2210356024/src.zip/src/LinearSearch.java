public class LinearSearch {
    public static int search(int[] array, int x) {
        int size = array.length;
        for (int i = 0; i < size; i++) {
            if (array[i] == x) return i;
        }
        return -1;
    }
}
