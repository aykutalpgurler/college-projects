import java.util.Arrays;

public class MergeSort {
    public static int[] sort(int[] array) {
        int n = array.length;
        if (n <= 1) return array;
        int[] left = sort(Arrays.copyOfRange(array, 0, n / 2));
        int[] right = sort(Arrays.copyOfRange(array, n / 2, n));
        return merge(left, right);
    }
    private static int[] merge(int[] A, int[] B) {
        int[] c = new int[A.length + B.length];
        int i = 0, j = 0, k = 0;
        while (i < A.length && j < B.length) {
            if (A[i] <= B[j]) {
                c[k++] = A[i++];
            } else {
                c[k++] = B[j++];
            }
        }
        while (i < A.length) {
            c[k++] = A[i++];
        }
        while (j < B.length) {
            c[k++] = B[j++];
        }
        return c;
    }
}
