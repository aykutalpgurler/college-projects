import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CSVReader {
    public static int[] read(String filePath) {
        List<Integer> columnValues = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 7) {
                    try {
                        int value = Integer.parseInt(parts[6]);
                        columnValues.add(value);
                    } catch (NumberFormatException e) {
                        // Ignore non-integer values
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return columnValues.stream().mapToInt(Integer::intValue).toArray();
    }
}
