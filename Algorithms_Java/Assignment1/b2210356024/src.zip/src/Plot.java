import org.knowm.xchart.*;
import org.knowm.xchart.style.Styler;
import java.io.IOException;
import java.util.Arrays;

public class Plot {
    public static void showAndSaveChart(String title, int[] xAxis, long[][] yAxis, String seriesName1, String seriesName2, String seriesName3, String timeUnit) throws IOException {
        // Create Chart
        XYChart chart = new XYChartBuilder().width(800).height(600).title(title)
                .yAxisTitle("Time in " + timeUnit).xAxisTitle("Input Size").build();

        // Convert x axis to double[]
        double[] doubleX = Arrays.stream(xAxis).asDoubleStream().toArray();

        // Convert long[][] arrays to double[][]
        double[][] doubleYAxis = new double[yAxis.length][];
        for (int i = 0; i < yAxis.length; i++) {
            doubleYAxis[i] = Arrays.stream(yAxis[i]).asDoubleStream().toArray();
        }

        // Customize Chart
        chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNE);
        chart.getStyler().setDefaultSeriesRenderStyle(XYSeries.XYSeriesRenderStyle.Line);

        // Add a plot for a sorting algorithm
        chart.addSeries(seriesName1, doubleX, doubleYAxis[0]);
        chart.addSeries(seriesName2, doubleX, doubleYAxis[1]);
        chart.addSeries(seriesName3, doubleX, doubleYAxis[2]);

        // Save the chart as PNG
        BitmapEncoder.saveBitmap(chart, title + ".png", BitmapEncoder.BitmapFormat.PNG);

        // Show the chart
        new SwingWrapper(chart).displayChart();
    }
}
