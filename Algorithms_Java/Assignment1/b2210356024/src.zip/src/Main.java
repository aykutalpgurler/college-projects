import java.io.IOException;
import java.util.Arrays;

class Main {
    public static void main(String args[]) throws IOException {

        long start = System.currentTimeMillis();

        System.out.println("Program has started running. Wait for results..." + "\n");

        int[] input = CSVReader.read(args[0]);

        long[] isr = Experiment.handle(Arrays.copyOfRange(input, 0, 250000), "InsertionSort", "Random");
        long[] msr = Experiment.handle(Arrays.copyOfRange(input, 0, 250000), "MergeSort", "Random");
        long[] csr = Experiment.handle(Arrays.copyOfRange(input, 0, 250000), "CountingSort", "Random");

        long[] iss = Experiment.handle(Arrays.copyOfRange(input, 0, 250000), "InsertionSort", "Sorted");
        long[] mss = Experiment.handle(Arrays.copyOfRange(input, 0, 250000), "MergeSort", "Sorted");
        long[] css = Experiment.handle(Arrays.copyOfRange(input, 0, 250000), "CountingSort", "Sorted");

        long[] isrs = Experiment.handle(Arrays.copyOfRange(input, 0, 250000), "InsertionSort", "ReverselySorted");
        long[] msrs = Experiment.handle(Arrays.copyOfRange(input, 0, 250000), "MergeSort", "ReverselySorted");
        long[] csrs = Experiment.handle(Arrays.copyOfRange(input, 0, 250000), "CountingSort", "ReverselySorted");

        long[] lsr = Experiment.handle(Arrays.copyOfRange(input, 0, 250000), "LinearSearch", "Random");
        long[] lss = Experiment.handle(Arrays.copyOfRange(input, 0, 250000), "LinearSearch", "Sorted");
        long[] bss = Experiment.handle(Arrays.copyOfRange(input, 0, 250000), "BinarySearch", "Sorted");

        long end = System.currentTimeMillis();

        long executionTime = end - start;

        System.out.println("Program Execution Time: " + executionTime + "ms");

        int[] inputSizes = {500, 1000, 2000, 4000, 8000, 16000, 32000, 64000, 128000, 250000};

        long[][] randomSorts = {isr, msr, csr};
        long[][] sortedSorts = {iss, mss, css};
        long[][] reverselySortedSorts = {isrs, msrs, csrs};
        long[][] searches = {lsr, lss, bss};

        Plot.showAndSaveChart("Tests On Random Data", inputSizes, randomSorts, "Insertion Sort", "Merge Sort", "Counting Sort", "Milliseconds");
        Plot.showAndSaveChart("Tests On Sorted Data", inputSizes, sortedSorts, "Insertion Sort", "Merge Sort", "Counting Sort", "Milliseconds");
        Plot.showAndSaveChart("Tests On Reversely Sorted Data", inputSizes, reverselySortedSorts, "Insertion Sort", "Merge Sort", "Counting Sort", "Milliseconds");
        Plot.showAndSaveChart("Tests On Search Algorithms", inputSizes, searches, "LS on Random Data", "LS on Sorted Data", "BS on Sorted Data", "Nanoseconds");
    }
}
